    clear all;
    data = textread('norwegianpaper.txt');
    Y    = data(:,1:13); 
    X    = data(:,14:22);
    Cov  = corrcoef(X);
    A    = mean(Y);
    B    = median(Y);
    q    = size(Y,2);
    N    = ceil(q/9);
    Hetero   = [];
    Hetero_p = [];
%% VIF
    VIF = diag(inv(Cov));

%% ɢ��ͼ��
    for j=2
        figure(j);
        for k=(1+9*(j-1)):9*j
            if k>q
               break;
            end
    statsA = regstats(Y(:,k),X,'linear','all');
    %all--{'yhat','r','standres','studres'});
         i = k-9*(j-1);
    subplot(2,2,i);
    %% ��̬�Լ���
    %hist(statsA.studres,30);
    %% �췽�����  
        %scatter(statsA.yhat,statsA.r.^2);
    %% for outlier
        scatter(statsA.yhat,statsA.standres);
        hold on;
        yhat_min = min(statsA.yhat)-1;
        yhat_max = max(statsA.yhat)+1;
        plot([yhat_min yhat_max],[-2 -2],[yhat_min yhat_max],[2 2]);
       %% �������Լ���
%            if (statsA.dwstat.pval < 0.05)
%             Hetero   = [Hetero k];
%             Hetero_p = [Hetero_p statsA.dwstat.pval];
%            end
       %%
   %%
        xlabel('Fitted Values'); 
        ylabel('Standarized Residuals (y_k)');
        end
        
        set(0,'DefaultFigureWindowStyle','docked');
    end
   