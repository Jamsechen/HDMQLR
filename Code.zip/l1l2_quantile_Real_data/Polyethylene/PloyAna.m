clear all;
X     = textread('polyethyleneX.txt');
Y     = textread('polyethyleneY.txt');%data(:,1:13);%textread('ArabY.txt')';
Y     = [10^5./Y(:,1) 10^6./Y(:,2) Y(:,3:6)];
[n,m] = size(X);
q     = size(Y,2);
A = [10.^X(:,1:20)+100 X(:,[21 22])];
Cov = corrcoef(X(:,1:20));
% %% VIF
% VIF = diag(inv(Cov));
% 
% %% Boxplot
% G = [zeros(size(Y(:,1)))  .25*ones(size(Y(:,2)))  .5*ones(size(Y(:,3)))  .75*ones(size(Y(:,4)))...
%     1*ones(size(Y(:,5)))  1.25*ones(size(Y(:,6)))];
% boxplot(Y(:,6));

%% Multilinearity
for k=1:q
    statsA = regstats(Y(:,k),X,'linear',{'yhat','r','standres'});
    subplot(3,2,k);
    scatter(statsA.yhat,statsA.r.^2,'k');
    %hold on;
    %plot([m m],[0 15]);
    %hold on;
    %plot([n n],[0 15]);
    xlabel('Fitted Values'); 
    ylabel('Residuals (y_k)');
end
set(0,'DefaultFigureWindowStyle','docked');
% 
% 
