%function [OUT,Results] = eg_huber(b,d,et,cor)
   clear all;
   addpath('ADMM_Quantile');
   addpath('Arab_data');
   addpath('Polyethylene');
   addpath('Norwegianpaper');
   N  = 2;  % repeat time
        
%% Load read data
    
    %X  = textread('polyethyleneX.txt'); 
    %Y  = textread('polyethyleneY.txt'); 
    
    %X  =textread('predictor_Arab.txt')';
    %Y  =textread('response_Arab.txt')';
   
    %data = textread('norwegianpaper.txt');
    %Y    = data(:,1:13); 
    %X    = data(:,14:22);
    % Stocks data
  [X,Y,LL] = readdata(10098);

    q  = size(Y,2);         m  = size(X,2);
    B0 = zeros(m,q);
%% data transform
    %Y  = log(Y); 
    %X  = log(X); % log-transform to reduce the skewness of the data
    X   = zscore(X);  
    Y   = zscore(Y); % standardize
    tau = 0.1:0.1:0.9;     l_tau = length(tau);
    
%%--------------Global parameters------------------
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

quan_para.kappa   = 10^(-3);  % used in smoothong quantile
quan_para.xi      = 10^(-3);  % used in Majorize-Minimize
quan_para.tol     = 10^(-5);  % tollerance error
linesearch        = 1;
quan_para.line    = 0.7;      % used in linesearch
quan_para.sigma   = 0.1;      % Parameter in Augmented Lagrangian
quan_para.Lagtype = 'change'; % fixed--sigma is fixed; change--sigma changes;
quan_para.update  = 'new';    % used in sbcd ADMM; 
                              % new--use the new B_{j.} in the next iteration; 
                              % old--use the old B_{j.} in the next iteration;
quan_para.gamma   = (1+sqrt(5))/2; % stepsize
quan_para.B0      = B0;
%% Repeat N times
for l=1:N  
    [Y_tr,X_tr,Y_te,X_te] = datasplit(Y,X);% split data 
    N_tr = size(Y_tr,1);
    N_te = size(Y_te,1);
    
 %% 5-fold CV   
    nFold = 5; %10;
    c_out = cvpartition(N_tr,'k',nFold); 
for k=1:nFold
    Tr_data_X = X_tr(training(c_out,k),:);    Tr_data_Y = Y_tr(training(c_out,k),:); 
    Va_data_X = X_tr(test(c_out,k),:);        Va_data_Y = Y_tr(test(c_out,k),:);
    N_Va      = size(Va_data_Y,1); 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ADMM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    quan_para.maxiter = 1000; 
    delta_A1          = 2*10^(-1);
    A1_Va_MSE         = zeros(l_tau,200);
for s=1:l_tau
    lambda_A1   = Generate_TuningPara_l1l2_quantile(Tr_data_X,Tr_data_Y,tau(s),delta_A1); 
    l_lambda_A1 = length(lambda_A1); 
for j=1:l_lambda_A1
    [A1_B_tr,Supp_A1_B_tr,Z,Supp_Z,A1_Time] = ADMM_Quantile(Tr_data_X,Tr_data_Y,tau(s),lambda_A1(j),quan_para);
    A1_Va_MSE(s,j) = A1_Va_MSE(s,j) + norm(Va_data_Y - Va_data_X*Z,'fro')^2;
    %+ log(Quan_value(Va_data_Y - Va_data_X*Z,tau(s))/N_Va)+log(N_Va)*length(Supp_Z)/N_Va;% test Response's MSE
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Proximal ADMM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    quan_para.maxiter = 1000; 
    delta_A2          = 2*10^(-1);
    A2_Va_MSE         = zeros(l_tau,200);
for s=1:l_tau
    lambda_A2     = Generate_TuningPara_l1l2_quantile(Tr_data_X,Tr_data_Y,tau(s),delta_A2); 
    l_lambda_A2   = length(lambda_A2); 
for j=1:l_lambda_A2
    [A2_B_tr,Supp_A2_B_tr,A2_Time] = pADMM_Quantile(Tr_data_X,Tr_data_Y,tau(s),lambda_A2(j),quan_para);
    A2_Va_MSE(s,j) = A2_Va_MSE(s,j) + norm(Va_data_Y - Va_data_X*A2_B_tr,'fro')^2;
    %log(Quan_value(Va_data_Y - Va_data_X*A2_B_tr,tau(s))/N_Va) + log(N_Va)*length(Supp_A2_B_tr)/N_Va;% test Response's MSE
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% sbcd ADMM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    quan_para.maxiter = 1000; 
    delta_A3          = 2*10^(-1);
    A3_Va_MSE         = zeros(l_tau,200);
for s=1:l_tau
    lambda_A3   = Generate_TuningPara_l1l2_quantile(Tr_data_X,Tr_data_Y,tau(s),delta_A3); 
    l_lambda_A3 = length(lambda_A3); 
for j=1:l_lambda_A3
    [A3_B_tr,Supp_A3_B_tr,A3_Time] = sbcdADMM_Quantile(Tr_data_X,Tr_data_Y,tau(s),lambda_A3(j),quan_para);
    A3_Va_MSE(s,j) = A3_Va_MSE(s,j) + norm(Va_data_Y - Va_data_X*A3_B_tr,'fro')^2;
    %log(Quan_value(Va_data_Y - Va_data_X*A3_B_tr,tau(s))/N_Va)+log(N_Va)*length(Supp_A3_B_tr)/N_Va;% test Response's MSE
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% lower Smooth quantile %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    smoothtype        = 'lower';
    quan_para.maxiter = 5000; 
    delta_A4          = 2*10^(-1);
    A4_Va_MSE         = zeros(l_tau,200);
for s=1:l_tau
    quan_para.tau = tau(s);   
    lambda_A4     = Generate_TuningPara_l1l2_quantile(Tr_data_X,Tr_data_Y,tau(s),delta_A4); 
    l_lambda_A4   = length(lambda_A4); 
for j=1:l_lambda_A4
    [A4_B_tr,Supp_A4_B_tr,A4_Time] = Smooth_Quantile(X,Y,lambda_A4(j),linesearch,quan_para,smoothtype);
    A4_Va_MSE(s,j) = A4_Va_MSE(s,j) + norm(Va_data_Y - Va_data_X*A4_B_tr,'fro')^2;
    %log(Quan_value(Va_data_Y - Va_data_X*A4_B_tr,tau(s))/N_Va)+log(N_Va)*length(Supp_A4_B_tr)/N_Va;% test Response's MSE
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% upper Smooth quantile %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    smoothtype        = 'upper';
    quan_para.maxiter = 5000; 
    delta_A5          = 2*10^(-1);
    A5_Va_MSE         = zeros(l_tau,200);
for s=1:l_tau
    quan_para.tau = tau(s);   
    lambda_A5     = Generate_TuningPara_l1l2_quantile(Tr_data_X,Tr_data_Y,tau(s),delta_A5); 
    l_lambda_A5   = length(lambda_A5); 
for j=1:l_lambda_A5
    [A5_B_tr,Supp_A5_B_tr,A5_Time] = Smooth_Quantile(X,Y,lambda_A5(j),linesearch,quan_para,smoothtype);
    A5_Va_MSE(s,j) = A5_Va_MSE(s,j) + norm(Va_data_Y - Va_data_X*A5_B_tr,'fro')^2;
    %log(Quan_value(Va_data_Y - Va_data_X*A5_B_tr,tau(s))/N_Va)+ log(N_Va)*length(Supp_A5_B_tr)/N_Va;% test Response's MSE
end
end

%%%%%%%%%%%%%%%%%%%% Majorize-Minimize lower Smooth quantile with linesearch %%%%%%%%%%%%%%%%%%%%%%%%%%%
    smoothtype        = 'lower';
    quan_para.maxiter = 5000; 
    delta_A6          = 2*10^(-1);
    A6_Va_MSE         = zeros(l_tau,200);
for s=1:l_tau
    quan_para.tau = tau(s);   
    lambda_A6     = Generate_TuningPara_l1l2_quantile(Tr_data_X,Tr_data_Y,tau(s),delta_A6); 
    l_lambda_A6   = length(lambda_A6); 
for j=1:l_lambda_A6
    [A6_B_tr,Supp_A6_B_tr,A6_Time] = Smooth_QuantileMML(X,Y,lambda_A6(j),linesearch,quan_para,smoothtype);
    A6_Va_MSE(s,j) = A6_Va_MSE(s,j) + norm(Va_data_Y - Va_data_X*A6_B_tr,'fro')^2;
    %log(Quan_value(Va_data_Y - Va_data_X*A6_B_tr,tau(s))/N_Va)+ log(N_Va)*length(Supp_A6_B_tr)/N_Va;% test Response's MSE
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%% Majorize-Minimize upper Smooth quantile with linesearch %%%%%%%%%%%%%%%%%%%%%%%%%%%
    smoothtype        = 'upper';
    quan_para.maxiter = 5000; 
    delta_A7          = 2*10^(-1);
    A7_Va_MSE         = zeros(l_tau,200);
for s=1:l_tau
    quan_para.tau = tau(s);   
    lambda_A7     = Generate_TuningPara_l1l2_quantile(Tr_data_X,Tr_data_Y,tau(s),delta_A7); 
    l_lambda_A7   = length(lambda_A7); 
for j=1:l_lambda_A7
    [A7_B_tr,Supp_A7_B_tr,A7_Time] = Smooth_QuantileMML(X,Y,lambda_A7(j),linesearch,quan_para,smoothtype);
    A7_Va_MSE(s,j) = A7_Va_MSE(s,j) + norm(Va_data_Y - Va_data_X*A7_B_tr,'fro')^2;
    %log(Quan_value(Va_data_Y - Va_data_X*A7_B_tr,tau(s))/N_Va) + log(N_Va)*length(Supp_A7_B_tr)/N_Va;% test Response's MSE
end
end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ADMM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %% select tuning parameter 
    CY = nFold*norm(Va_data_Y,'fro')^2;
    [A1_R,A1_C] = find(A1_Va_MSE==CY);
    LN = length(A1_R);
for i=1:LN
    A1_Va_MSE(A1_R(i),A1_C(i)) = 1e+100;
end
   [A1_r,A1_c] = find(A1_Va_MSE==min(min(A1_Va_MSE)));
   A1_tau      = tau(A1_r(1));
   A1_lambda   = lambda_A1(A1_c(1));

%% Compute the estimator
   [A1_B_new,Supp_A1_B_new,Z_new,Supp_Z_new,A1_Time] = ADMM_Quantile(X_tr,Y_tr,A1_tau,A1_lambda,quan_para);
   A1_RMSPE(l)   = norm(Y_te - X_te*Z_new)/(N_te*q);
   A1_Supp{l}    = Supp_Z_new;
   A1_NumSupp(l) = length(Supp_Z_new);
   A1_Cpu(l)     = A1_Time;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Proximal ADMM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %% select tuning parameter 
    CY = nFold*norm(Va_data_Y,'fro')^2;
    [A2_R,A2_C] = find(A2_Va_MSE==CY);
    LN = length(A2_R);
for i=1:LN
    A2_Va_MSE(A2_R(i),A2_C(i)) = 1e+100;
end
   [A2_r,A2_c] = find(A2_Va_MSE==min(min(A2_Va_MSE)));
   A2_tau      = tau(A2_r(1));
   A2_lambda   = lambda_A2(A2_c(1));

%% Compute the estimator
   [A2_B_new,Supp_A2_B_new,A2_Time] = pADMM_Quantile(X_tr,Y_tr,A2_tau,A2_lambda,quan_para);
   A2_RMSPE(l)   = norm(Y_te - X_te*A2_B_new)/(N_te*q);
   A2_Supp{l}    = Supp_A2_B_new;
   A2_NumSupp(l) = length(Supp_A2_B_new);
   A2_Cpu(l)     = A2_Time;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% sbcd ADMM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %% select tuning parameter 
    CY = nFold*norm(Va_data_Y,'fro')^2;
    [A3_R,A3_C] = find(A3_Va_MSE==CY);
    LN = length(A3_R);
for i=1:LN
    A3_Va_MSE(A3_R(i),A3_C(i)) = 1e+100;
end
   [A3_r,A3_c] = find(A3_Va_MSE==min(min(A3_Va_MSE)));
   A3_tau      = tau(A3_r(1));
   A3_lambda   = lambda_A3(A3_c(1));

%% Compute the estimator
   [A3_B_new,Supp_A3_B_new,A3_Time] = sbcdADMM_Quantile(X_tr,Y_tr,A3_tau,A3_lambda,quan_para);
   A3_RMSPE(l)   = norm(Y_te - X_te*A3_B_new)/(N_te*q);
   A3_Supp{l}    = Supp_A3_B_new;
   A3_NumSupp(l) = length(Supp_A3_B_new);
   A3_Cpu(l)     = A3_Time;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% lower Smooth quantile %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %% select tuning parameter 
    CY = nFold*norm(Va_data_Y,'fro')^2;
    [A4_R,A4_C] = find(A4_Va_MSE==CY);
    LN = length(A4_R);
for i=1:LN
    A4_Va_MSE(A4_R(i),A4_C(i)) = 1e+100;
end
   [A4_r,A4_c] = find(A4_Va_MSE==min(min(A4_Va_MSE)));
   A4_tau      = tau(A4_r(1));
   A4_lambda   = lambda_A4(A4_c(1));

%% Compute the estimator
   quan_para.tau = A4_tau;  
   smoothtype    = 'lower'; 
   [A4_B_new,Supp_A4_B_new,A4_Time] = Smooth_Quantile(X_tr,Y_tr,A4_lambda,linesearch,quan_para,smoothtype);
   A4_RMSPE(l)   = norm(Y_te - X_te*A4_B_new)/(N_te*q);
   A4_Supp{l}    = Supp_A4_B_new;
   A4_NumSupp(l) = length(Supp_A4_B_new);
   A4_Cpu(l)     = A4_Time;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% upper Smooth quantile  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %% select tuning parameter 
    CY = nFold*norm(Va_data_Y,'fro')^2;
    [A5_R,A5_C] = find(A5_Va_MSE==CY);
    LN = length(A5_R);
for i=1:LN
    A5_Va_MSE(A5_R(i),A5_C(i)) = 1e+100;
end
   [A5_r,A5_c] = find(A5_Va_MSE==min(min(A5_Va_MSE)));
   A5_tau      = tau(A5_r(1));
   A5_lambda   = lambda_A5(A5_c(1));

%% Compute the estimator
   quan_para.tau = A5_tau;  
   smoothtype    = 'upper'; 
   [A5_B_new,Supp_A5_B_new,A5_Time] = Smooth_Quantile(X_tr,Y_tr,A5_lambda,linesearch,quan_para,smoothtype);
   A5_RMSPE(l)   = norm(Y_te - X_te*A5_B_new)/(N_te*q);
   A5_Supp{l}    = Supp_A5_B_new;
   A5_NumSupp(l) = length(Supp_A5_B_new);
   A5_Cpu(l)     = A5_Time;
   
%%%%%%%%%%%%%%%%%%%%%% Majorize-Minimize lower Smooth quantile with linesearch %%%%%%%%%%%%%%%%%%%%%%%
 %% select tuning parameter 
    CY = nFold*norm(Va_data_Y,'fro')^2;
    [A6_R,A6_C] = find(A6_Va_MSE==CY);
    LN = length(A6_R);
for i=1:LN
    A6_Va_MSE(A6_R(i),A6_C(i)) = 1e+100;
end
   [A6_r,A6_c] = find(A6_Va_MSE==min(min(A6_Va_MSE)));
   A6_tau      = tau(A6_r(1));
   A6_lambda   = lambda_A6(A6_c(1));

%% Compute the estimator
   quan_para.tau = A6_tau;  
   smoothtype    = 'lower'; 
   [A6_B_new,Supp_A6_B_new,A6_Time] = Smooth_QuantileMML(X_tr,Y_tr,A6_lambda,linesearch,quan_para,smoothtype);
   A6_RMSPE(l)   = norm(Y_te - X_te*A6_B_new)/(N_te*q);
   A6_Supp{l}    = Supp_A6_B_new;
   A6_NumSupp(l) = length(Supp_A6_B_new);
   A6_Cpu(l)     = A6_Time;
   
%%%%%%%%%%%%%%%%%%%%%% Majorize-Minimize lower Smooth quantile with linesearch %%%%%%%%%%%%%%%%%%%%%%%
 %% select tuning parameter 
    CY = nFold*norm(Va_data_Y,'fro')^2;
    [A7_R,A7_C] = find(A7_Va_MSE==CY);
    LN = length(A7_R);
for i=1:LN
    A7_Va_MSE(A7_R(i),A7_C(i)) = 1e+100;
end
   [A7_r,A7_c] = find(A7_Va_MSE==min(min(A7_Va_MSE)));
   A7_tau      = tau(A7_r(1));
   A7_lambda   = lambda_A7(A7_c(1));

%% Compute the estimator
   quan_para.tau = A7_tau;  
   smoothtype    = 'upper'; 
   [A7_B_new,Supp_A7_B_new,A7_Time] = Smooth_QuantileMML(X_tr,Y_tr,A7_lambda,linesearch,quan_para,smoothtype);
   A7_RMSPE(l)   = norm(Y_te - X_te*A7_B_new)/(N_te*q);
   A7_Supp{l}    = Supp_A7_B_new;
   A7_NumSupp(l) = length(Supp_A7_B_new);
   A7_Cpu(l)     = A7_Time;
   
end

%% Mean result
   mean_A1_RMSPE   = mean(A1_RMSPE);       std_A1_RMSPE   = std(A1_RMSPE);
   mean_A2_RMSPE   = mean(A2_RMSPE);       std_A2_RMSPE   = std(A2_RMSPE);
   mean_A3_RMSPE   = mean(A3_RMSPE);       std_A3_RMSPE   = std(A3_RMSPE);
   mean_A4_RMSPE   = mean(A4_RMSPE);       std_A4_RMSPE   = std(A4_RMSPE);
   mean_A5_RMSPE   = mean(A5_RMSPE);       std_A5_RMSPE   = std(A5_RMSPE);
   mean_A6_RMSPE   = mean(A6_RMSPE);       std_A6_RMSPE   = std(A6_RMSPE);
   mean_A7_RMSPE   = mean(A7_RMSPE);       std_A7_RMSPE   = std(A7_RMSPE);

   mean_A1_NumSupp = median(A1_NumSupp);    
   mean_A2_NumSupp = median(A2_NumSupp);   
   mean_A3_NumSupp = median(A3_NumSupp);  
   mean_A4_NumSupp = median(A4_NumSupp);    
   mean_A5_NumSupp = median(A5_NumSupp);   
   mean_A6_NumSupp = median(A6_NumSupp);     
   mean_A7_NumSupp = median(A7_NumSupp);     
   
   mean_A1_Cpu    = mean(A1_Cpu);          std_A1_Cpu     = std(A1_Cpu);
   mean_A2_Cpu    = mean(A2_Cpu);          std_A2_Cpu     = std(A2_Cpu);
   mean_A3_Cpu    = mean(A3_Cpu);          std_A3_Cpu     = std(A3_Cpu);
   mean_A4_Cpu    = mean(A4_Cpu);          std_A4_Cpu     = std(A4_Cpu);
   mean_A5_Cpu    = mean(A5_Cpu);          std_A5_Cpu     = std(A5_Cpu);
   mean_A6_Cpu    = mean(A6_Cpu);          std_A6_Cpu     = std(A6_Cpu);
   mean_A7_Cpu    = mean(A7_Cpu);          std_A7_Cpu     = std(A7_Cpu);

%% ***********************************************************************************************
format shortE
Results = ...
{   'Estimator',            'A1',            'A2',            'A3',            'A4',            'A5',            'A6',            'A7';...
  'mean(RMSPE)',   mean_A1_RMSPE,   mean_A2_RMSPE,   mean_A3_RMSPE,   mean_A4_RMSPE,   mean_A5_RMSPE,   mean_A6_RMSPE,   mean_A7_RMSPE;...
   'std(RMSPE)',    std_A1_RMSPE,    std_A2_RMSPE,    std_A3_RMSPE,    std_A4_RMSPE,    std_A5_RMSPE,    std_A6_RMSPE,    std_A7_RMSPE;...
'mean(NumSupp)', mean_A1_NumSupp, mean_A2_NumSupp, mean_A3_NumSupp, mean_A4_NumSupp, mean_A5_NumSupp, mean_A6_NumSupp, mean_A7_NumSupp;...
    'mean(Cpu)',     mean_A1_Cpu,     mean_A2_Cpu,     mean_A3_Cpu,     mean_A4_Cpu,     mean_A5_Cpu,     mean_A6_Cpu,     mean_A7_Cpu;...
     'std(Cpu)',      std_A1_Cpu,      std_A2_Cpu,      std_A3_Cpu,      std_A4_Cpu,      std_A5_Cpu,      std_A6_Cpu,      std_A7_Cpu;}

Resultstxt= [mean_A1_RMSPE,   mean_A2_RMSPE,   mean_A3_RMSPE,   mean_A4_RMSPE,   mean_A5_RMSPE,   mean_A6_RMSPE,   mean_A7_RMSPE;...
              std_A1_RMSPE,    std_A2_RMSPE,    std_A3_RMSPE,    std_A4_RMSPE,    std_A5_RMSPE,    std_A6_RMSPE,    std_A7_RMSPE;...
           mean_A1_NumSupp, mean_A2_NumSupp, mean_A3_NumSupp, mean_A4_NumSupp, mean_A5_NumSupp, mean_A6_NumSupp, mean_A7_NumSupp;...
               mean_A1_Cpu,     mean_A2_Cpu,     mean_A3_Cpu,     mean_A4_Cpu,     mean_A5_Cpu,     mean_A6_Cpu,     mean_A7_Cpu;...
                std_A1_Cpu,      std_A2_Cpu,      std_A3_Cpu,      std_A4_Cpu,      std_A5_Cpu,      std_A6_Cpu,      std_A7_Cpu;];

dlmwrite('Results.txt', Resultstxt, 'precision', '%.8f','delimiter', '\t','newline', 'pc');