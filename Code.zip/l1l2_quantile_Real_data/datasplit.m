function [B_training,A_training,B_test,A_test]=datasplit(B,A)
 %% split the data for training and test
 n                     = size(B,1);
 randomn               = randperm(n); 
 K = ceil(0.8*n);
 sample_training_index = randomn(1:K);%training indices
 B_training = B(sample_training_index,:);
 B(sample_training_index,:)=[ ];
 B_test = B;
 A_training = A(sample_training_index,:);
 A(sample_training_index,:)=[ ];
 A_test = A;