function C = readcsv(name) 
fid = fopen(name); 
C = textscan(fid,'%d%d%d%d%d%f%f%s%s%s%s%s%s%s%d%d%f%f%d%d%d%s%s%s%s%s%s%s%s','Delimiter',', ', 'HeaderLines',1);
%C = textscan(fid,'%d%d%d%f%f%d%s%d%d%f%f%d%d','Delimiter',', ', 'HeaderLines',1);
fclose(fid);

