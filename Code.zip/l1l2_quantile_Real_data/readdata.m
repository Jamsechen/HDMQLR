function [X,Y,LL] = readdata(N)
%% N = 10098
  S  = readmatrix('symbols_valid_meta.csv','OutputType', 'string');
  lS = length(S);
 name = [ ];
    for l=1:lS
     if S(l,5)=='Q'
       name = [name S(l,11)]; 
     end
    end

addpath('stocks');     %addpath('etfs'); 
lname = length(name);
X = [ ];   Y = [ ];
LL = [ ];
for i=1:lname
data = readmatrix(strcat(name(i),'.csv') ,'OutputType', 'double');
if length(data(:,1))==N&(name(i)~='FARM')&(name(i)~='FELE')
    LL = [LL name(i)];
    Y = [Y data(:,5)];
    X = [X data(:,[2 3 4 7]) data(:,2).*data(:,3) data(:,2).*data(:,4) data(:,2).*data(:,7)...
         data(:,3).*data(:,4) data(:,3).*data(:,7) data(:,4).*data(:,7)];
end
end